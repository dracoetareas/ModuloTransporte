{
    'name': "caa_transporte",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,
    'author': "My Company",
    'website': "https://www.yourcompany.com",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base'],
    'data': [
        'security/grupos.xml',
        'security/ir.model.access.csv',
        'views/camion.xml',
        'views/remolque.xml',
        'views/aviso_revision.xml',
        'views/reparacion.xml',
        'views/menus.xml'
    ],
    'demo': [
        'demo/demo.xml'
    ],
        'icon': '/caa_transporte/static/description/icono.png'
}

