from odoo import models, fields, api
from datetime import datetime, date

class Camion(models.Model):
    _name = 'caa_transporte.camion'
    _description = 'Camion'

    nombre = fields.Char(string='Nombre', required=True, help="Introduce el nombre del transportista")
    modelo = fields.Char(string='Modelo', help="Introduce el tipo de modelo del camion")
    matricula = fields.Char(string='Matricula', required=True, help="Introduce matricula")
    kilometros = fields.Float(string='Kilometros Recorridos', help="Introduce los kilometros")
    imagen = fields.Binary(string='Imagen del camion', help="Sube una imagen del estado del camion")
    remolque_ids = fields.Many2many( #Relacion entre camiones y remolques
        'caa_transporte.remolque', 
        'caa_transporte_camion_remolque_rel', 
        'camion_id', 'remolque_id', 
        string='Remolques'
    )
    
    reparacion_ids = fields.One2many(
        'caa_transporte.reparacion',
        'camion_id',
        string='Reparaciones'
    )

    coste_total_reparaciones = fields.Float(
        string='Coste Total Reparaciones',
        compute='compute_coste_total_reparaciones', 
        store=True
    )
    
    ultima_reparacion = fields.Date(
        string='Fecha ultima reparacion',
        compute='_compute_ultima_reparacion',
        inverse='_inverse_ultima_reparacion',
        store=True
    )

    km_promedio_diario = fields.Float(
        string='Promedio KM/Dia desde ultima reparacion',
        compute='_compute_km_promedio_diario',
        help="Promedio kilometros recorridos por dia desde la ultima reparacion"
    )
    
    #Funciones:
    #Calcular coste total de las reparaciones, hace una suma y calcula el total
    @api.depends('reparacion_ids.coste')
    def compute_coste_total_reparaciones(self):
        for camion in self:
            camion.coste_total_reparaciones = sum(reparacion.coste for reparacion in camion.reparacion_ids)

    #Calculo de los km hechos desde la ultima reparacion
    @api.depends('reparacion_ids.fecha')
    def _compute_ultima_reparacion(self):
        for camion in self:
            if camion.reparacion_ids:
                camion.ultima_reparacion = max(camion.reparacion_ids.mapped('fecha'))
            else:
                camion.ultima_reparacion = False

    def _inverse_ultima_reparacion(self):
        for camion in self:
            if camion.ultima_reparacion:
                if not camion.reparacion_ids:
                    self.env['caa_transporte.reparacion'].create({
                        'camion_id': camion.id,
                        'fecha': camion.ultima_reparacion,
                        'descripcion': 'Actualizacion manual de fecha',
                        'coste': 0,
                    })
                else:
                    ultima_reparacion = max(camion.reparacion_ids, key=lambda r: r.fecha)
                    ultima_reparacion.fecha = camion.ultima_reparacion

    @api.depends('kilometros', 'ultima_reparacion')
    def _compute_km_promedio_diario(self):
        for camion in self:
            if camion.ultima_reparacion:
                dias_desde_reparacion = (date.today() - camion.ultima_reparacion).days
                if dias_desde_reparacion > 0:
                    camion.km_promedio_diario = camion.kilometros / dias_desde_reparacion
                else:
                    camion.km_promedio_diario = 0
            else:
                camion.km_promedio_diario = 0