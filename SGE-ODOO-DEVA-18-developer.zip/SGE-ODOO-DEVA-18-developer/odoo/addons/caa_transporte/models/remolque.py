from odoo import models, fields

class Remolque(models.Model):
    _name = 'caa_transporte.remolque'
    _description = 'Remolque'

    name = fields.Char(string='Nombre', required=True)
    modelo = fields.Char(string='Modelo')
    matricula = fields.Char(string='Matricula', required=True)
    camion_ids = fields.Many2many( #Relacion entre remolques y camiones
        'caa_transporte.camion', 
        'caa_transporte_camion_remolque_rel', 
        'remolque_id', 'camion_id', 
        string='Camiones')