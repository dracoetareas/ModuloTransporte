from odoo import models, fields

class AvisoRevision(models.Model):
    _name = 'caa_transporte.aviso_revision'
    _description = 'Aviso de Revision'
    
    name = fields.Char(string='Descripcion', required=True)
    camion_id = fields.Many2one('caa_transporte.camion', string='Camion', required=True)
    fecha = fields.Date(string='Fecha de revision', required=True)
    kilometros = fields.Float(string='Kilometros del vehiculo')