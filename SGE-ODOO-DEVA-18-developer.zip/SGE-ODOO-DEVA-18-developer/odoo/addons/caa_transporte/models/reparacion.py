from odoo import models, fields

class Reparacion(models.Model):
    _name = 'caa_transporte.reparacion'
    _description = 'Reparacion'

    name = fields.Char(string='Descripcion', required=True)
    #Relacion entre reparaciones y camion
    camion_id = fields.Many2one('caa_transporte.camion', string='Camion', required=True)
    fecha = fields.Date(string='Fecha de reparacion', required=True)
    coste = fields.Float(string='Coste total')